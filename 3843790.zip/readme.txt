Name: Jingxuan Feng
Student Number: s3843790

The code will run like any other Jupyter Notebook file, no additional setup / configuration is required. 